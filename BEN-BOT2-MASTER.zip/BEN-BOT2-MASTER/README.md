## BEN BOT 

<p align="center">
<img src="https://avatars2.githubusercontent.com/u/70950474?s=400&u=6c56f74017c9eed3cc75b29367c06be0c3839bda&v=4" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="Whatsapp-Termux-Bot" src="https://img.shields.io/badge/Whatsapp Termux Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/ben-dev2609"><img title="Author" src="https://img.shields.io/badge/Author-Ebenezer-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/ben-dev2609/followers"><img title="Followers" src="https://img.shields.io/github/followers/ben-dev2609?color=blue&style=flat-square"></a>
<a href="https://github.com/ben-dev2609/BEN-BOT2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/ben-dev2609/BEN-BOT2?color=red&style=flat-square"></a>
<a href="https://github.com/ben-dev2609/BEN-BOT2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/ben-dev2609/BEN-BOT2?color=red&style=flat-square"></a>
<a href="https://github.com/ben-dev2609/whatsapp-bott/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/ben-dev2609/BEN-BOT2?label=Watchers&color=blue&style=flat-square"></a>
</p>




 

## Installation





# Termux
```bash
> termux-setup-storage
> pkg install git
> apt update && apt upgrade
> git clone https://github.com/ben-dev2609/BEN-BOT2
> cd BEN-BOT2
> pkg install wget
> pkg install ffmpeg
> pkg install nodejs
> npm i -g cwebp
> npm i -g ytdl
> npm i
> npm i got
> node index.js
```

# Linux 
```bash
> git clone https://github.com/ben-dev2609/BEN-BOT2
> cd BEN-BOT2
> bash install.sh

```

# Windows

Clone the project and run 



### Usage
1. run the Whatsapp bot

```bash
> node index.js
```

after running it you need to scan the qr


## FEATURES

| STATUS        |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS                             |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,IG,TWT DOWNLOADER        |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|      BETA      | WELCOME ENABLE/DISABLE             |









## DONASI
* [`Saweria`](https://saweria.co/Ebenezer)
